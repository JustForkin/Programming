disp('test runs:');

Quantum1(2, 2, 1);
Quantum1(2, 4, 1);
Quantum1(3, 4, 3);
Quantum1(3, 3, 5);
Quantum1(0, 4, 12);
Quantum1(10, 4, 7);