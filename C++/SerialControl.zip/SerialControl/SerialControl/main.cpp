#include "SerialGui.h"
#include <windows.h>
#include "Serial.h"
#include "stdafx.h"

#include <string>
#include <iostream>

#include <QtGui/QApplication>
#include <QLineEdit>
#include <QPushButton>
#include <QString>
#include <QSplitter>
using namespace std;

void printUsage(_TCHAR progName[]);



int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	
	SerialGui w;
	w.show();
	
    return a.exec();
}


void printUsage(_TCHAR progName[])
{
#if defined(UNICODE)
	wcout << progName << " <comm port>" << endl
		<< "e.g., " << progName << " COM1" << endl;
#else
	cout << progName << " <comm port>" << endl
		<< "e.g., " << progName << " COM1" << endl;
#endif

}

